<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        
        <!-- Header & Action -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white">🏛️ E-Library Kampus</h2>
            
            <!-- Tombol Tambah (Hanya Admin) -->
            @if(in_array(Auth::user()->role, ['Admin', 'Superadmin']))
                <a href="{{ route('library.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold shadow hover:bg-indigo-700 transition">
                    + Tambah Buku
                </a>
            @endif
        </div>

        <!-- Search & Filter -->
        <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-6 flex flex-col md:flex-row gap-4">
            <input wire:model.live.debounce.300ms="search" type="text" placeholder="Cari judul atau penulis..." class="flex-1 rounded-lg border-gray-300 dark:bg-gray-900 dark:text-white">
            <select wire:model.live="filterCategory" class="rounded-lg border-gray-300 dark:bg-gray-900 dark:text-white">
                <option value="">Semua Kategori</option>
                <option>Teknologi</option>
                <option>Bisnis</option>
                <option>Sains</option>
                <option>Umum</option>
            </select>
        </div>

        @if (session()->has('message'))
            <div class="bg-green-100 text-green-700 p-3 rounded mb-4">{{ session('message') }}</div>
        @endif

        <!-- Grid Buku -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            @forelse($ebooks as $book)
                <div class="group bg-white dark:bg-gray-800 rounded-xl shadow-md hover:shadow-xl transition duration-300 overflow-hidden border border-gray-200 dark:border-gray-700 flex flex-col h-full">
                    
                    <!-- Cover Image -->
                    <div class="h-48 overflow-hidden bg-gray-100 relative">
                        @if($book->cover_path)
                            <img src="{{ asset('storage/' . $book->cover_path) }}" class="w-full h-full object-cover transition duration-500 group-hover:scale-110">
                        @else
                            <!-- Placeholder Cover jika tidak ada gambar -->
                            <div class="w-full h-full flex flex-col items-center justify-center text-gray-400">
                                <svg class="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                                <span class="text-xs font-bold">{{ $book->category }}</span>
                            </div>
                        @endif
                        
                        <!-- Badge Kategori -->
                        <div class="absolute top-2 right-2 bg-black/60 text-white text-[10px] px-2 py-1 rounded backdrop-blur-sm">
                            {{ $book->category }}
                        </div>
                    </div>

                    <!-- Info -->
                    <div class="p-4 flex-1 flex flex-col">
                        <h3 class="font-bold text-gray-900 dark:text-white text-lg leading-tight mb-1 line-clamp-2" title="{{ $book->title }}">
                            {{ $book->title }}
                        </h3>
                        <p class="text-sm text-gray-500 mb-3">{{ $book->author }}</p>
                        
                        <!-- Tombol Action -->
                        <div class="mt-auto pt-3 border-t border-gray-100 dark:border-gray-700 flex justify-between items-center">
                            <!-- Download Button (Link langsung) -->
                            <a href="{{ asset('storage/' . $book->file_path) }}" target="_blank" class="text-indigo-600 font-bold text-sm hover:underline flex items-center">
                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                                Baca / Unduh
                            </a>

                            <!-- Hapus (Admin Only) -->
                            @if(in_array(Auth::user()->role, ['Admin', 'Superadmin']))
                                <button wire:click="deleteEbook({{ $book->id }})" wire:confirm="Hapus buku ini?" class="text-red-400 hover:text-red-600">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-span-full text-center py-10 text-gray-500">
                    Tidak ada buku yang ditemukan.
                </div>
            @endforelse
        </div>
        
        <div class="mt-6">
            {{ $ebooks->links() }}
        </div>
    </div>
</div>