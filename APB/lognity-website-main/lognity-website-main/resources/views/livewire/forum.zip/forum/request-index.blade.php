<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        
        <!-- Notifikasi -->
        @if (session()->has('message'))
            <div class="bg-green-100 text-green-700 px-4 py-3 rounded mb-4">{{ session('message') }}</div>
        @endif

        <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
            
            <!-- KOLOM KIRI: FILTER & SEARCH -->
            <div class="lg:col-span-1 space-y-6">
                
                <!-- Card Pencarian & Filter -->
                <div class="bg-white p-4 rounded-lg shadow sticky top-6">
                    <h3 class="font-bold text-gray-700 mb-4 border-b pb-2">🔍 Cari & Filter</h3>
                    
                    <!-- Search -->
                    <div class="mb-4">
                        <label class="text-xs font-bold text-gray-500">Kata Kunci / Matkul</label>
                        <input wire:model.live.debounce.300ms="search" type="text" class="w-full border-gray-300 rounded text-sm" placeholder="Cari...">
                    </div>

                    <!-- Kategori -->
                    <div class="mb-4">
                        <label class="text-xs font-bold text-gray-500">Kategori</label>
                        <select wire:model.live="filterCategory" class="w-full border-gray-300 rounded text-sm">
                            <option value="">Semua Kategori</option>
                            <option>Catatan</option>
                            <option>Tugas</option>
                            <option>Jawaban UTS/UAS</option>
                            <option>Kuis</option>
                            <option>Presentasi</option>
                            <option>Mindmap</option>
                            <option>Diskusi</option>
                            <option>Latihan</option>
                            <option>Proyek</option>
                            <option>Lain-Lain</option>
                        </select>
                    </div>

                    <!-- Fakultas -->
                    <div class="mb-4">
                        <label class="text-xs font-bold text-gray-500">Fakultas</label>
                        <select wire:model.live="filterFaculty" class="w-full border-gray-300 rounded text-sm">
                            <option value="">Semua Fakultas</option>
                            <option value="Teknik">Teknik</option>
                            <option value="Ekonomi">Ekonomi</option>
                            <option value="Ilmu Komputer">Ilmu Komputer</option>
                            <option value="Kedokteran">Kedokteran</option>
                            <!-- Tambahkan fakultas lain -->
                        </select>
                    </div>

                    <!-- Urutkan -->
                    <div class="mb-4">
                        <label class="text-xs font-bold text-gray-500">Urutkan</label>
                        <select wire:model.live="sort" class="w-full border-gray-300 rounded text-sm">
                            <option value="latest">Terbaru</option>
                            <option value="popular">Terpopuler (Upvotes)</option>
                            <option value="oldest">Terlama</option>
                        </select>
                    </div>

                    <button wire:click="$set('search', ''); $set('filterCategory', ''); $set('filterFaculty', '')" 
                            class="w-full bg-gray-200 text-gray-600 text-xs py-2 rounded hover:bg-gray-300">
                        Reset Filter
                    </button>
                </div>
            </div>

            <!-- KOLOM KANAN: FORM CREATE & LIST -->
            <div class="lg:col-span-3 space-y-6">
                
                <!-- FORM BUAT REQUEST BARU (DENGAN INPUT BARU) -->
                <div x-data="{ open: false }" class="bg-white p-6 rounded-lg shadow">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-lg font-semibold">Butuh Materi? Buat Request!</h2>
                        <button @click="open = !open" class="text-sm text-indigo-600 hover:underline">
                            <span x-show="!open">+ Buka Form</span>
                            <span x-show="open">- Tutup Form</span>
                        </button>
                    </div>
                    
                    <div x-show="open" x-transition class="mt-4">
                        <form wire:submit.prevent="createRequest">
                            <textarea wire:model="description" class="w-full border-gray-300 rounded-md shadow-sm mb-3" placeholder="Deskripsikan requestmu..." rows="3"></textarea>
                            @error('description') <span class="text-red-500 text-sm block mb-2">{{ $message }}</span> @enderror

                            <div class="grid grid-cols-2 gap-4 mb-3">
                                <div>
                                    <label class="text-xs font-bold text-gray-500">Kategori</label>
                                    <select wire:model="category" class="w-full border-gray-300 rounded text-sm">
                                        <option>Lain-Lain</option>
                                        <option>Catatan</option>
                                        <option>Tugas</option>
                                        <option>Jawaban UTS/UAS</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="text-xs font-bold text-gray-500">Fakultas (Opsional)</label>
                                    <input wire:model="faculty" type="text" class="w-full border-gray-300 rounded text-sm" placeholder="Contoh: Fasilkom">
                                </div>
                                <div>
                                    <label class="text-xs font-bold text-gray-500">Mata Kuliah (Opsional)</label>
                                    <input wire:model="course_name" type="text" class="w-full border-gray-300 rounded text-sm" placeholder="Contoh: Aljabar">
                                </div>
                                <div>
                                    <label class="text-xs font-bold text-gray-500">Lampiran</label>
                                    <input type="file" wire:model="attachment" class="w-full text-xs">
                                </div>
                            </div>

                            <div class="text-right">
                                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Post Request</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- LIST REQUEST -->
                <div class="space-y-4">
                    @forelse($requests as $req)
                        <div class="bg-white p-6 rounded-lg shadow hover:shadow-md transition border border-gray-100">
                            <div class="flex justify-between items-start">
                                <div class="w-full">
                                    <!-- Header Kecil -->
                                    <div class="flex items-center space-x-2 text-xs text-gray-500 mb-2">
                                        <span class="font-bold text-indigo-600">{{ $req->user->username }}</span>
                                        <span>•</span>
                                        <span class="bg-gray-100 px-2 py-0.5 rounded text-gray-600">{{ $req->category }}</span>
                                        @if($req->course_name) <span>• {{ $req->course_name }}</span> @endif
                                        <span class="ml-auto">{{ $req->created_at->diffForHumans() }}</span>
                                    </div>
                                    
                                    <!-- Konten Utama -->
                                    <div class="flex gap-4">
                                        <!-- Tombol Upvote (Kiri) -->
                                        <div class="flex flex-col items-center mr-2">
                                            <button wire:click="toggleUpvote({{ $req->request_id }})" 
                                                class="flex flex-col items-center group transition hover:-translate-y-1">
                                                
                                                <!-- Icon Panah -->
                                                <svg class="w-8 h-8 transition {{ $req->is_upvoted ? 'text-orange-500 fill-current' : 'text-gray-400 group-hover:text-orange-400' }}" 
                                                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"></path>
                                                </svg>
                                                
                                                <!-- Angka Count -->
                                                <span class="font-bold text-lg {{ $req->is_upvoted ? 'text-orange-600' : 'text-gray-600' }}">
                                                    {{ $req->upvotes_count }}
                                                </span>
                                            </button>
                                        </div>

                                        <!-- Deskripsi & Detail -->
                                        <div class="flex-1">
                                            <a href="{{ route('forum.show', $req->request_id) }}" wire:navigate class="block text-xl font-medium text-gray-900 hover:text-indigo-600 mb-2">
                                                {{ Str::limit($req->description, 150) }}
                                            </a>
                                            
                                            <!-- Tags Bawah -->
                                            <div class="flex items-center justify-between mt-4">
                                                <div class="flex space-x-3 text-sm text-gray-500">
                                                    <span class="flex items-center">
                                                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
                                                        {{ $req->answers_count }} Jawaban
                                                    </span>
                                                    @if($req->faculty)
                                                        <span class="flex items-center">
                                                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                                                            {{ $req->faculty }}
                                                        </span>
                                                    @endif
                                                </div>

                                                <a href="{{ route('forum.show', $req->request_id) }}" class="px-3 py-1 bg-indigo-50 text-indigo-700 text-xs font-bold rounded hover:bg-indigo-100">
                                                    Jawab / Lihat
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="text-center py-12 bg-white rounded-lg shadow">
                            <p class="text-gray-500 text-lg">Tidak ada request yang cocok dengan filter.</p>
                            <button wire:click="$set('search', ''); $set('filterCategory', ''); $set('filterFaculty', '')" class="text-indigo-600 hover:underline mt-2">
                                Reset Filter
                            </button>
                        </div>
                    @endforelse
                    
                    <div class="mt-4">
                        {{ $requests->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Script untuk handling Alert Poin Kurang (Opsional, pakai sweetalert atau alert biasa) -->
<script>
    document.addEventListener('livewire:initialized', () => {
        Livewire.on('alert', (data) => {
            alert(data[0].message); // Alert browser biasa sederhana
        });
    });
</script>