<!-- 👇 ROOT WRAPPER (Sangat Penting untuk Livewire) 👇 -->
<div> 
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Notifikasi Flash Message -->
            @if (session()->has('message'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                    {{ session('message') }}
                </div>
            @endif

            <!-- BAGIAN 1: PERTANYAAN UTAMA (REQUEST) -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-6 border-l-4 border-indigo-500">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    
                    <!-- Header: User Info + Status + Report -->
                    <div class="flex justify-between items-start mb-4">
                        <!-- Kiri: Info User -->
                        <div class="flex items-center">
                            <img src="{{ asset('storage/' . $request->user->profil) }}" alt="Avatar" class="w-10 h-10 rounded-full bg-gray-300 mr-3 object-cover">
                            <div>
                                <div class="font-bold text-lg">{{ $request->user->username }}</div>
                                <div class="text-xs text-gray-500">{{ $request->user->current_level }} • {{ $request->created_at->diffForHumans() }}</div>
                            </div>
                        </div>

                        <!-- Kanan: Status & Report -->
                        <div class="flex items-center space-x-2">
                            <!-- Badge Status -->
                            <span class="px-3 py-1 rounded-full text-xs font-bold {{ $request->status == 'Open' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' }}">
                                {{ $request->status }}
                            </span>

                            <!-- Tombol Lapor Request -->
                            @if(Auth::id() !== $request->user_id)
                                <button type="button" wire:click="openReportModal('request', {{ $request->request_id }})" class="text-gray-400 hover:text-red-500 transition cursor-pointer" title="Laporkan Konten">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                                </button>
                            @endif
                        </div>
                    </div>

                    <!-- Judul / Deskripsi -->
                    <h1 class="text-xl md:text-2xl font-bold mb-4 whitespace-pre-line">{{ $request->description }}</h1>

                    <!-- LOGIKA TAMPILAN LAMPIRAN REQUEST -->
                    @if($request->attachment_file)
                        @php
                            $ext = strtolower(pathinfo($request->attachment_file, PATHINFO_EXTENSION));
                            $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                        @endphp

                        <div class="mt-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-100 dark:border-gray-700">
                            <p class="text-sm font-bold text-gray-500 mb-2 flex items-center">
                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path></svg>
                                Lampiran:
                            </p>
                            
                            @if($isImage)
                                <a href="{{ asset('storage/' . $request->attachment_file) }}" target="_blank">
                                    <img src="{{ asset('storage/' . $request->attachment_file) }}" alt="Lampiran" class="max-w-lg w-full rounded-lg shadow-md border border-gray-200 hover:opacity-90 transition">
                                </a>
                            @else
                                <a href="{{ asset('storage/' . $request->attachment_file) }}" target="_blank" class="inline-flex items-center p-3 bg-white dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600 hover:bg-gray-100 transition shadow-sm">
                                    <svg class="w-8 h-8 mr-3 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                                    <div>
                                        <span class="block text-sm font-bold text-gray-800 dark:text-gray-200">Download File</span>
                                        <span class="text-xs text-gray-500 uppercase">{{ $ext }} File</span>
                                    </div>
                                </a>
                            @endif
                        </div>
                    @endif
                </div> 
            </div> 

            <!-- JUMLAH JAWABAN -->
            <div class="mb-4">
                <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-4">
                    {{ $request->answers->count() }} Jawaban
                </h3>
            </div>

            <!-- LIST JAWABAN -->
            <div class="space-y-4 mb-8">
                @forelse($request->answers as $answer)
                    <!-- Tambahkan wire:key agar livewire tidak bingung -->
                    <div wire:key="answer-{{ $answer->interaction_id }}" class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow 
                        {{ $answer->is_accepted_answer ? 'border-2 border-green-500 bg-green-50 dark:bg-gray-700' : '' }}">
                        
                        <div class="flex justify-between items-start">
                            <div class="flex items-center mb-2">
                                <span class="font-bold text-gray-800 dark:text-gray-200">{{ $answer->user->username }}</span>
                                
                                <!-- TOMBOL LAPOR JAWABAN -->
                                @if($answer->user_id !== Auth::id())
                                    <button type="button" wire:click="openReportModal('interaction', {{ $answer->interaction_id }})" class="ml-2 text-gray-400 hover:text-red-500 text-xs font-bold transition cursor-pointer" title="Laporkan Jawaban">
                                        [Lapor]
                                    </button>
                                @endif

                                <span class="mx-2 text-gray-400">•</span>
                                <span class="text-sm text-gray-500">{{ $answer->created_at->diffForHumans() }}</span>
                            </div>
                            
                            @if($answer->is_accepted_answer)
                                <span class="flex items-center text-green-600 font-bold text-sm bg-green-100 px-3 py-1 rounded-full">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                                    Accepted Answer
                                </span>
                            @endif
                        </div>

                        <div class="text-gray-700 dark:text-gray-300 mt-2 mb-4 whitespace-pre-line">
                            {{ $answer->content }}

                            <!-- LAMPIRAN JAWABAN -->
                            @if($answer->material) 
                                @php
                                    $matExt = strtolower(pathinfo($answer->material->file_path, PATHINFO_EXTENSION));
                                    $matIsImage = in_array($matExt, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                                @endphp
                                <div class="mt-3">
                                    @if($matIsImage)
                                        <p class="text-xs font-bold text-gray-500 mb-1">Lampiran Gambar:</p>
                                        <a href="{{ asset('storage/' . $answer->material->file_path) }}" target="_blank">
                                            <img src="{{ asset('storage/' . $answer->material->file_path) }}" class="max-w-sm w-full rounded-lg shadow border border-gray-200 hover:opacity-90 transition">
                                        </a>
                                    @else
                                        <div class="flex items-center p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg max-w-md shadow-sm">
                                            <div class="mr-3 text-indigo-500">
                                                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                                            </div>
                                            <div class="flex-1 overflow-hidden">
                                                <div class="text-sm font-bold text-gray-800 dark:text-gray-200 truncate">
                                                    {{ $answer->material->title }}
                                                </div>
                                                <a href="{{ asset('storage/' . $answer->material->file_path) }}" target="_blank" class="text-xs text-indigo-600 hover:text-indigo-800 font-bold">
                                                    Download {{ strtoupper($matExt) }}
                                                </a>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            @endif
                        </div>

                        @if(Auth::id() === $request->user_id && $request->status === 'Open' && $answer->user_id !== Auth::id())
                            <div class="border-t pt-3 mt-3 border-gray-100 dark:border-gray-600">
                                <button wire:click="markAsAccepted({{ $answer->interaction_id }})" 
                                        onclick="confirm('Tandai ini sebagai jawaban terbaik? (+50 Poin untuk penjawab)') || event.stopImmediatePropagation()"
                                        class="text-sm text-indigo-600 hover:text-indigo-800 font-semibold flex items-center cursor-pointer">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    Terima Jawaban Ini
                                </button>
                            </div>
                        @endif
                    </div>
                @empty
                    <div class="text-center py-10 text-gray-500 bg-white dark:bg-gray-800 rounded-lg shadow">
                        Belum ada jawaban. Jadilah yang pertama membantu!
                    </div>
                @endforelse
            </div>

            <!-- FORM TULIS JAWABAN -->
            @if($request->status === 'Open')
                <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg mt-6">
                    <h3 class="font-bold text-lg mb-4 text-gray-800 dark:text-gray-200">Tulis Jawaban</h3>
                    <form wire:submit.prevent="submitAnswer">
                        <textarea wire:model="content" rows="4" class="w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 rounded-md shadow-sm mb-4 focus:border-indigo-500 focus:ring-indigo-500" placeholder="Berikan solusi..."></textarea>
                        @error('content') <span class="text-red-500 text-sm block mb-2">{{ $message }}</span> @enderror

                        <div class="mb-4 border-t border-gray-100 dark:border-gray-700 pt-4">
                            <label class="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Lampirkan Materi/File (Opsional)</label>
                            <input type="file" wire:model="file" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"/>
                            <div wire:loading wire:target="file" class="text-indigo-500 text-xs font-bold mt-1">Uploading...</div>
                            @error('file') <span class="text-red-500 text-sm block mt-1">{{ $message }}</span> @enderror
                        </div>

                        <div class="flex justify-end">
                            <button type="submit" wire:loading.attr="disabled" class="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-indigo-700 transition disabled:opacity-50">
                                Kirim Jawaban
                            </button>
                        </div>
                    </form>
                </div>
            @else
                <div class="bg-gray-200 dark:bg-gray-700 p-4 rounded text-center text-gray-500 dark:text-gray-300 font-semibold mt-6">
                    🔒 Topik ini telah diselesaikan (Resolved).
                </div>
            @endif

        </div>
    </div>

    <!-- REPORT MODAL OVERLAY (Sekarang ada di DALAM root div) -->
    @if($showReportModal)
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-60 backdrop-blur-sm">
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md mx-4 animate-fade-in-down">
                <h3 class="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4 border-b pb-2">⚠ Laporkan Konten</h3>
                <p class="text-sm text-gray-500 mb-4">Jelaskan alasan Anda melaporkan konten ini.</p>
                
                <textarea wire:model="reportReason" class="w-full border-gray-300 dark:bg-gray-900 dark:text-gray-200 rounded mb-2 focus:ring-red-500 focus:border-red-500" rows="3" placeholder="Contoh: Spam, Kata kasar, SARA..."></textarea>
                @error('reportReason') <span class="text-red-500 text-xs block mb-4 font-bold">{{ $message }}</span> @enderror

                <div class="flex justify-end space-x-2 mt-4">
                    <button wire:click="closeReportModal" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 font-semibold transition">Batal</button>
                    <button wire:click="submitReport" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 font-semibold transition">Kirim Laporan</button>
                </div>
            </div>
        </div>
    @endif
</div> 
<!-- 👆 PENUTUP ROOT DIV 👆 -->