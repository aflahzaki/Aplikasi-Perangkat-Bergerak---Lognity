<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

namespace App\Services;

class ContentModerator
{
    public static function check($text)
    {
        $text = strtolower($text); // Ubah ke huruf kecil semua

        // 1. DAFTAR KATA KASAR (Simulasi AI)
        // Silakan tambah kata-kata untuk pengetesan
        $badWords = [
            'bodoh', 'tolol', 'anjing', 'bangsat', 'stupid'
        ];

        // 2. DAFTAR KATA SEKSUAL (Untuk tes fitur -25 Poin)
        $sexualWords = [
            'porn', 'bugil', 'telanjang', 'bokep', 'mesum', 'boobs'
        ];

        // 3. LOGIKA PENGECEKAN
        
        // Cek kategori Seksual dulu
        foreach ($sexualWords as $word) {
            if (str_contains($text, $word)) {
                return [
                    'is_toxic' => true,
                    'category' => 'sexual' // Kategori ini memicu -25 Poin
                ];
            }
        }

        // Cek kategori Kasar umum
        foreach ($badWords as $word) {
            if (str_contains($text, $word)) {
                return [
                    'is_toxic' => true,
                    'category' => 'harassment/hate'
                ];
            }
        }

        // 4. AMAN
        return ['is_toxic' => false, 'category' => null];
    }
}